# my-website-starter-kit 

> A simple starter kit that with the following dependencies: gulp, pug, postcss, browser-sync, imagemin & lost-grid.

## Install

```
$ npm install --save-dev
```

## License

MIT © [Alex Yakir](http://alexyakir.com/)
